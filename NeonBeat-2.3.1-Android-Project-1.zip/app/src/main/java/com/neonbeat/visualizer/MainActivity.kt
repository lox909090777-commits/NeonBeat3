package com.neonbeat.visualizer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val prefs = getSharedPreferences("neonbeat", MODE_PRIVATE)
            val uids = selectedUids(this, prefs.getString("active_profile", "medium") ?: "medium")
            val serviceIntent = Intent(this, AudioCaptureService::class.java).apply {
                putExtra("resultCode", result.resultCode)
                putExtra("projectionData", result.data)
                putExtra("uids", uids.toIntArray())
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            prefs.edit().putBoolean("captureRequested", true).apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeonBeatSettings(
            startCapture = {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mgr.createScreenCaptureIntent())
            },
            stopCapture = { stopService(Intent(this, AudioCaptureService::class.java)) }
        ) }
    }
}

private data class InstalledApp(val packageName: String, val label: String, val uid: Int)

private fun launchableApps(context: Context): List<InstalledApp> {
    val pm = context.packageManager
    return try {
        pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != context.packageName && pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { InstalledApp(it.packageName, pm.getApplicationLabel(it).toString(), it.uid) }
            .distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    } catch (_: Exception) { emptyList() }
}

private fun selectedUids(context: Context, profile: String): Set<Int> {
    val p = context.getSharedPreferences("neonbeat", Context.MODE_PRIVATE)
    val apps = launchableApps(context)
    val prefix = "profile_${profile}_"
    val selected = mutableSetOf<Int>()
    if (p.getBoolean(prefix + "source_spotify", true))
        selected += apps.filter { it.packageName == "com.spotify.music" }.map { it.uid }
    if (p.getBoolean(prefix + "source_ytmusic", true))
        selected += apps.filter { it.packageName == "com.google.android.apps.youtube.music" }.map { it.uid }
    if (p.getBoolean(prefix + "source_youtube", true))
        selected += apps.filter { it.packageName == "com.google.android.youtube" }.map { it.uid }
    if (p.getBoolean(prefix + "source_local", true)) {
        val hints = listOf("music", "player", "audio", "vlc", "foobar", "poweramp", "musicolet", "jet")
        selected += apps.filter { a -> hints.any { a.label.contains(it, true) || a.packageName.contains(it, true) } }.map { it.uid }
    }
    if (p.getBoolean(prefix + "source_other", false)) {
        val known = setOf("com.spotify.music", "com.google.android.apps.youtube.music", "com.google.android.youtube")
        selected += apps.filter { it.packageName !in known }.map { it.uid }
    }
    val manuallySelected = p.getStringSet(prefix + "apps", emptySet()) ?: emptySet()
    selected += apps.filter { it.packageName in manuallySelected }.map { it.uid }
    return selected
}

private fun prefFloat(context: Context, key: String, default: Float) =
    context.getSharedPreferences("neonbeat", Context.MODE_PRIVATE).getFloat(key, default)

@Composable
private fun NeonBeatSettings(startCapture: () -> Unit, stopCapture: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("neonbeat", Activity.MODE_PRIVATE) }

    var profile by remember { mutableStateOf(prefs.getString("active_profile", "medium") ?: "medium") }
    fun profileKey(key: String) = "profile_${profile}_${key}"
    fun profileFloat(key: String, fallback: Float) = prefs.getFloat(profileKey(key), fallback)
    fun profileBool(key: String, fallback: Boolean) = prefs.getBoolean(profileKey(key), fallback)
    fun profileString(key: String, fallback: String) = prefs.getString(profileKey(key), fallback) ?: fallback

    var style by remember { mutableStateOf(profileString("style", "Spectrum")) }
    var bars by remember { mutableFloatStateOf(profileFloat("bars", 42f)) }
    var thickness by remember { mutableFloatStateOf(profileFloat("thickness", 0.65f)) }
    var spacing by remember { mutableFloatStateOf(profileFloat("spacing", 0.25f)) }
    var sensitivity by remember { mutableFloatStateOf(prefFloat(context, "sensitivity", 1.6f)) }
    var bass by remember { mutableFloatStateOf(prefFloat(context, "bass", 1.5f)) }
    var smoothing by remember { mutableFloatStateOf(prefFloat(context, "smoothing", 0.35f)) }
    var glow by remember { mutableFloatStateOf(profileFloat("glow", 0.55f)) }
    var roundness by remember { mutableFloatStateOf(profileFloat("roundness", 0.7f)) }
    var opacity by remember { mutableFloatStateOf(profileFloat("opacity", 0.85f)) }
    var height by remember { mutableFloatStateOf(profileFloat("height", 0.8f)) }
    var mirror by remember { mutableStateOf(profileBool("mirror", false)) }
    var showApps by remember { mutableStateOf(false) }
    var spotify by remember { mutableStateOf(profileBool("source_spotify", true)) }
    var ytm by remember { mutableStateOf(profileBool("source_ytmusic", true)) }
    var youtube by remember { mutableStateOf(profileBool("source_youtube", true)) }
    var local by remember { mutableStateOf(profileBool("source_local", true)) }
    var other by remember { mutableStateOf(profileBool("source_other", false)) }
    var selectedPackages by remember(profile) {
        mutableStateOf((prefs.getStringSet("profile_${profile}_apps", emptySet()) ?: emptySet()).toSet())
    }

    val apps = remember { launchableApps(context) }
    val styles = listOf("Spectrum", "Кольцо", "Волна", "Импульс", "Частицы", "Зеркало", "Столбцы", "Неон")
    val colorOptions = listOf("Циан / фиолетовый", "Огонь", "Лёд", "Розовый", "Зелёный", "Белый")
    var palette by remember { mutableStateOf(profileString("palette", colorOptions[0]) ?: colorOptions[0]) }
    var backgroundHex by remember { mutableStateOf(profileString("backgroundHex", "#101426") ?: "#101426") }

    fun saveFloat(key: String, value: Float) { prefs.edit().putFloat(profileKey(key), value).apply() }
    fun saveBool(key: String, value: Boolean) { prefs.edit().putBoolean(profileKey(key), value).apply() }
    fun saveString(key: String, value: String) { prefs.edit().putString(profileKey(key), value).apply() }
    fun saveSource(key: String, value: Boolean) { prefs.edit().putBoolean(profileKey(key), value).apply() }
    fun toggleApp(pkg: String, checked: Boolean) {
        selectedPackages = if (checked) selectedPackages + pkg else selectedPackages - pkg
        prefs.edit().putStringSet(profileKey("apps"), selectedPackages.toSet()).apply()
    }
    fun loadProfile(next: String) {
        profile = next
        prefs.edit().putString("active_profile", next).apply()
        style = prefs.getString("profile_${next}_style", "Spectrum") ?: "Spectrum"
        bars = prefs.getFloat("profile_${next}_bars", 42f)
        thickness = prefs.getFloat("profile_${next}_thickness", 0.65f)
        spacing = prefs.getFloat("profile_${next}_spacing", 0.25f)
        glow = prefs.getFloat("profile_${next}_glow", 0.55f)
        roundness = prefs.getFloat("profile_${next}_roundness", 0.7f)
        opacity = prefs.getFloat("profile_${next}_opacity", 0.85f)
        height = prefs.getFloat("profile_${next}_height", 0.8f)
        mirror = prefs.getBoolean("profile_${next}_mirror", false)
        palette = prefs.getString("profile_${next}_palette", colorOptions[0]) ?: colorOptions[0]
        backgroundHex = prefs.getString("profile_${next}_backgroundHex", "#101426") ?: "#101426"
        spotify = prefs.getBoolean("profile_${next}_source_spotify", true)
        ytm = prefs.getBoolean("profile_${next}_source_ytmusic", true)
        youtube = prefs.getBoolean("profile_${next}_source_youtube", true)
        local = prefs.getBoolean("profile_${next}_source_local", true)
        other = prefs.getBoolean("profile_${next}_source_other", false)
        selectedPackages = (prefs.getStringSet("profile_${next}_apps", emptySet()) ?: emptySet()).toSet()
        showApps = false
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB28CFF), secondary = Color(0xFF48DDEB), surface = Color(0xFF151A29))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF090B13)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("NEONBEAT 2.2", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                Text("Настрой визуализацию под себя", color = Color(0xFF9EA8C5))
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A29))) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Профиль размера виджета", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("У каждого размера свои цвета, количество элементов, толщина, высота и эффекты.", color = Color(0xFFB9C1D8))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = profile == "small", onClick = { loadProfile("small") }, label = { Text("Маленький") }, modifier = Modifier.weight(1f))
                            FilterChip(selected = profile == "medium", onClick = { loadProfile("medium") }, label = { Text("Средний") }, modifier = Modifier.weight(1f))
                            FilterChip(selected = profile == "large", onClick = { loadProfile("large") }, label = { Text("Большой") }, modifier = Modifier.weight(1f))
                        }
                    }
                }
                VisualizerPreview(style, bars.toInt(), thickness, spacing, height, glow, roundness, opacity, mirror, palette)

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A29))) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text("Источники звука", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text("Без доступа к уведомлениям. Android отдельно спросит разрешение на захват звука.", color = Color(0xFFB9C1D8))
                        SourceToggle("Spotify", spotify) { spotify = it; saveSource("source_spotify", it) }
                        SourceToggle("YouTube Music", ytm) { ytm = it; saveSource("source_ytmusic", it) }
                        SourceToggle("YouTube", youtube) { youtube = it; saveSource("source_youtube", it) }
                        SourceToggle("Локальный плеер", local) { local = it; saveSource("source_local", it) }
                        SourceToggle("Другие приложения", other) { other = it; saveSource("source_other", it) }
                        TextButton(onClick = { showApps = !showApps }) { Text(if (showApps) "Скрыть установленные приложения" else "Показать установленные приложения") }
                        if (showApps) {
                            Text("Выберите приложения отдельно для профиля «${when(profile) { "small" -> "Маленький"; "large" -> "Большой"; else -> "Средний" }}»:", color = Color(0xFFB9C1D8))
                            apps.forEach { app ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(app.label, color = Color.White, style = MaterialTheme.typography.bodyMedium)
                                        Text(app.packageName, color = Color(0xFF8994AD), style = MaterialTheme.typography.labelSmall)
                                    }
                                    Checkbox(checked = app.packageName in selectedPackages,
                                        onCheckedChange = { toggleApp(app.packageName, it) })
                                }
                            }
                        }
                        Button(onClick = startCapture, modifier = Modifier.fillMaxWidth()) { Text("Разрешить захват и запустить") }
                        OutlinedButton(onClick = stopCapture, modifier = Modifier.fillMaxWidth()) { Text("Остановить") }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF151A29))) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Тип визуализации", color = Color.White, style = MaterialTheme.typography.titleLarge)
                        styles.chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                pair.forEach { name ->
                                    FilterChip(selected = style == name, onClick = { style = name; saveString("style", name) }, label = { Text(name) }, modifier = Modifier.weight(1f))
                                }
                                if (pair.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        Text("Цветовая схема", color = Color.White)
                        colorOptions.chunked(2).forEach { pair ->
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                pair.forEach { name ->
                                    FilterChip(selected = palette == name, onClick = { palette = name; saveString("palette", name) }, label = { Text(name) }, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        SettingSlider("Количество элементов: ${bars.toInt()}", bars, 8f..100f) { bars = it; saveFloat("bars", it) }
                        SettingSlider("Толщина: ${(thickness * 100).toInt()}%", thickness, 0.1f..1f) { thickness = it; saveFloat("thickness", it) }
                        SettingSlider("Расстояние: ${(spacing * 100).toInt()}%", spacing, 0f..1f) { spacing = it; saveFloat("spacing", it) }
                        SettingSlider("Высота эффекта: ${(height * 100).toInt()}%", height, 0.2f..1f) { height = it; saveFloat("height", it) }
                        SettingSlider("Чувствительность: ${(sensitivity * 100).toInt()}%", sensitivity, 0.2f..3f) { sensitivity = it; prefs.edit().putFloat("sensitivity", it).apply() }
                        SettingSlider("Усиление басов: ${(bass * 100).toInt()}%", bass, 0.5f..3f) { bass = it; prefs.edit().putFloat("bass", it).apply() }
                        SettingSlider("Плавность реакции: ${(smoothing * 100).toInt()}%", smoothing, 0f..1f) { smoothing = it; prefs.edit().putFloat("smoothing", it).apply() }
                        SettingSlider("Свечение: ${(glow * 100).toInt()}%", glow, 0f..1f) { glow = it; saveFloat("glow", it) }
                        SettingSlider("Скругление: ${(roundness * 100).toInt()}%", roundness, 0f..1f) { roundness = it; saveFloat("roundness", it) }
                        SettingSlider("Прозрачность визуализации: ${(opacity * 100).toInt()}%", opacity, 0.1f..1f) { opacity = it; saveFloat("opacity", it) }
                        SourceToggle("Зеркальное отображение", mirror) { mirror = it; saveBool("mirror", it) }
                        Text("Цвет фона (HEX)", color = Color.White)
                        OutlinedTextField(value = backgroundHex, onValueChange = {
                            backgroundHex = it.take(7)
                            saveString("backgroundHex", backgroundHex)
                        }, singleLine = true, label = { Text("Например #101426") })
                        Text("Фон и прозрачность применяются в предпросмотре/следующей версии виджета после обновления.", color = Color(0xFF9EA8C5), style = MaterialTheme.typography.bodySmall)
                    }
                }
                Text("Примечание: Android может не разрешить захват звука некоторым приложениям. Захват идёт только от выбранных UID и только пока активен системно разрешённый сеанс.", color = Color(0xFF8D98B2), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SourceToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SettingSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, color = Color(0xFFE8EAF4), style = MaterialTheme.typography.bodyMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun VisualizerPreview(style: String, count: Int, thickness: Float, spacing: Float, height: Float, glow: Float, roundness: Float, opacity: Float, mirror: Boolean, palette: String) {
    var frame by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(75); frame++ } }
    val colors = when (palette) {
        "Огонь" -> listOf(Color(0xFFFFD166), Color(0xFFFF5A36))
        "Лёд" -> listOf(Color(0xFFE0FFFF), Color(0xFF4AA8FF))
        "Розовый" -> listOf(Color(0xFFFF9AD5), Color(0xFFB44CFF))
        "Зелёный" -> listOf(Color(0xFFB8FF6A), Color(0xFF16C784))
        "Белый" -> listOf(Color.White, Color(0xFFB8C4D8))
        else -> listOf(Color(0xFF54E7F0), Color(0xFFB37CFF))
    }
    Canvas(Modifier.fillMaxWidth().height(166.dp).background(Color(0xFF101426), RoundedCornerShape(18.dp)).padding(12.dp)) {
        val n = count.coerceIn(4, 100)
        val gapPx = size.width * spacing.coerceIn(0f, 1f) / n
        val bw = ((size.width - gapPx * (n - 1)) / n) * thickness.coerceIn(0.1f, 1f)
        for (i in 0 until n) {
            val wave = (sin((i + frame * 0.18) * 0.46) * 0.5 + 0.5).toFloat()
            val h = size.height * height * (0.12f + wave * 0.78f)
            val x = i * (size.width / n) + (size.width / n - bw) / 2
            val alpha = opacity.coerceIn(0.1f, 1f)
            val brush = Brush.verticalGradient(colors.map { it.copy(alpha = alpha) })
            val top = if (mirror) size.height / 2 - h / 2 else (size.height - h) / 2
            val bottom = if (mirror) size.height / 2 + h / 2 else (size.height + h) / 2
            drawLine(brush = brush, start = Offset(x + bw / 2, top), end = Offset(x + bw / 2, bottom), strokeWidth = bw.coerceAtLeast(1f), cap = if (roundness > 0.5f) StrokeCap.Round else StrokeCap.Square)
            if (glow > 0.1f) {
                drawCircle(colors.first().copy(alpha = glow * 0.16f), radius = bw * 1.8f, center = Offset(x + bw / 2, size.height / 2))
            }
        }
    }
}
