package com.neonbeat.visualizer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread
import kotlin.math.sqrt

class AudioCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var recorder: AudioRecord? = null
    @Volatile private var capturing = false
    private var projectionCallback: MediaProjection.Callback? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT < 29) { stopSelf(); return START_NOT_STICKY }
        val channelId = "neonbeat_capture"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "NeonBeat audio capture", NotificationManager.IMPORTANCE_LOW))
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("NeonBeat работает")
            .setContentText("Захват звука выбранных приложений активен")
            .setOngoing(true).build()
        startForeground(9, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("projectionData", Intent::class.java)
                   else @Suppress("DEPRECATION") (intent?.getParcelableExtra("projectionData") as? Intent)
        if (data == null || resultCode == 0) { stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            // Android 14+ requires a registered callback for a MediaProjection session.
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() {
                    capturing = false
                    stopSelf()
                }
            }
            projection?.registerCallback(projectionCallback!!, android.os.Handler(mainLooper))
            beginCapture(intent?.getIntArrayExtra("uids") ?: intArrayOf())
        } catch (_: Exception) { stopSelf() }
        return START_NOT_STICKY
    }

    private fun beginCapture(uids: IntArray) {
        val p = projection ?: return
        if (uids.isEmpty()) { stopSelf(); return }
        val config = android.media.AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .apply { uids.distinct().forEach { addMatchingUid(it) } }
            .build()
        val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
        val min = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { stopSelf(); return }
        val rec = AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(min * 2)
            .setAudioPlaybackCaptureConfig(config).build()
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); stopSelf(); return }
        recorder = rec
        capturing = true
        rec.startRecording()
        thread(name = "NeonBeatCapture") {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
            val samples = ShortArray(min)
            var smoothed = 0f
            var lastWidgetUpdate = 0L
            while (capturing) {
                val n = rec.read(samples, 0, samples.size)
                if (n > 0) {
                    var power = 0.0
                    for (i in 0 until n) { val x = samples[i].toDouble() / 32768.0; power += x * x }
                    val rms = sqrt(power / n).toFloat()
                    val prefs = getSharedPreferences("neonbeat", MODE_PRIVATE)
                    val raw = (rms * prefs.getFloat("sensitivity", 1.6f) * 4f).coerceIn(0f, 1f)
                    val smooth = prefs.getFloat("smoothing", .35f).coerceIn(0f, 1f)
                    val attack = (0.18f + (1f - smooth) * 0.72f).coerceIn(.08f, .9f)
                    smoothed += (raw - smoothed) * attack
                    prefs.edit().putFloat("level", smoothed).apply()

                    // Home-screen widgets are not designed for 10+ FPS updates.
                    // Throttle updates to reduce battery use and avoid overwhelming the launcher.
                    val now = System.currentTimeMillis()
                    if (now - lastWidgetUpdate >= 500L) {
                        lastWidgetUpdate = now
                        VisualizerWidget.updateAll(this)
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        capturing = false
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        try {
            projectionCallback?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (_: Exception) {}
        projectionCallback = null
        projection = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
